/* Zona Orsay v0.5.1
 *
 * IMPORTANT: The TV cannot read the PC's network interfaces itself.
 * This value is the LAN address printed by server/server.py.
 * For your current home network it is expected to be 192.168.88.228.
 */
var ZONA_SERVER_URL = "http://192.168.88.230:8765";
var ZONA_POLL_MS = 2000;
