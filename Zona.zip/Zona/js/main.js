/* Zona Orsay v0.3 Diagnostic
 * Samsung F-Series / Orsay 2013
 *
 * Purpose: diagnose Player API + direct media URL connection.
 */

var widgetAPI = new Common.API.Widget();
var tvKey = new Common.API.TVKeyValue();

var player = null;
var network = null;
var actionIndex = 0;
var logLines = [];
var editingURL = false;
var lanPollTimer = null;
var lastRemoteURL = "";

var Main = {};

Main.onLoad = function() {
    widgetAPI.sendReadyEvent();

    player = document.getElementById("pluginPlayer");
    network = document.getElementById("pluginNetwork");

    registerKeys();
    bindPlayerEvents();
    renderActions();
    startLanPolling();

    if (player) {
        updateState("PLAYER FOUND", "SAMSUNG-INFOLINK-PLAYER");
        logOK("Widget", "ready");
        logOK("Player", "object found");
        probePlayer();
    } else {
        updateState("PLAYER NULL", "plugin object not created");
        logERR("Player", "object is NULL");
    }

    if (network) {
        logOK("Network", "plugin found");
        probeNetwork();
    } else {
        logERR("Network", "plugin not found");
    }
};

Main.onUnload = function() {
    try { stopPlayer(); } catch (e) {}
    try { if (lanPollTimer) window.clearInterval(lanPollTimer); } catch (e2) {}
};

function registerKeys() {
    try {
        if (typeof tvKey.registerKey == "function") {
            tvKey.registerKey(tvKey.KEY_UP);
            tvKey.registerKey(tvKey.KEY_DOWN);
            tvKey.registerKey(tvKey.KEY_LEFT);
            tvKey.registerKey(tvKey.KEY_RIGHT);
            tvKey.registerKey(tvKey.KEY_ENTER);
            tvKey.registerKey(tvKey.KEY_RETURN);
            tvKey.registerKey(tvKey.KEY_STOP);
        }
        logOK("Keys", "registered");
    } catch (e) {
        logERR("Keys", "registration failed: " + e);
    }
}

function bindPlayerEvents() {
    if (!player) return;

    try { player.OnBufferingStart = onBufferingStart; } catch (e1) {}
    try { player.OnBufferingProgress = onBufferingProgress; } catch (e2) {}
    try { player.OnBufferingComplete = onBufferingComplete; } catch (e3) {}
    try { player.OnConnectionFailed = onConnectionFailed; } catch (e4) {}
    try { player.OnCurrentPlayTime = onCurrentPlayTime; } catch (e5) {}
    try { player.OnNetworkDisconnected = onNetworkDisconnected; } catch (e6) {}
    try { player.OnRenderError = onRenderError; } catch (e7) {}
    try { player.OnRenderingComplete = onRenderingComplete; } catch (e8) {}
    try { player.OnResolutionChanged = onResolutionChanged; } catch (e9) {}
    try { player.OnStreamInfoReady = onStreamInfoReady; } catch (e10) {}
    try { player.OnStreamNotFound = onStreamNotFound; } catch (e11) {}
    try { player.OnAuthenticationFailed = onAuthenticationFailed; } catch (e12) {}

    logOK("Events", "callbacks attached");
}

function probePlayer() {
    var version = "n/a";
    var methods = [
        "InitPlayer", "SetDisplayArea", "SetInitialBufferSize", "SetInitialBuffer",
        "SetInitialTimeOut", "SetTotalBufferSize", "SetPendingBuffer",
        "SetPlayerProperty", "GetPlayerVersion", "GetAvailableBitrates",
        "GetCurrentBitrates", "GetDuration", "GetVideoWidth", "GetVideoHeight",
        "StartPlayback", "Play", "Pause", "Resume", "Stop"
    ];
    var i;

    try {
        if (typeof player.GetPlayerVersion == "function") version = player.GetPlayerVersion();
    } catch (e) { version = "ERR:" + e; }

    logOK("PlayerVersion", String(version));

    for (i = 0; i < methods.length; i++) {
        try {
            if (typeof player[methods[i]] == "function") logOK("API " + methods[i], "FOUND");
            else logERR("API " + methods[i], "NOT FOUND");
        } catch (e2) {
            logERR("API " + methods[i], "CHECK ERROR");
        }
    }
}

function probeNetwork() {
    var methods = ["CheckDNS", "CheckGateway", "GetStatus", "GetActiveType", "GetHostAddr", "GetDNS", "GetGateway", "GetIpType", "GetNetMask"];
    var i;
    for (i = 0; i < methods.length; i++) {
        try {
            if (typeof network[methods[i]] == "function") logOK("NET " + methods[i], "FOUND");
            else logERR("NET " + methods[i], "NOT FOUND");
        } catch (e) {
            logERR("NET " + methods[i], "CHECK ERROR");
        }
    }
}

function startLanPolling() {
    var line = document.getElementById("serverLine");
    if (line) line.innerHTML = "LAN SERVER: " + escapeHTML(ZONA_SERVER_URL);
    logOK("LAN", "polling " + ZONA_SERVER_URL);
    refreshRemoteURL();
    try {
        lanPollTimer = window.setInterval(refreshRemoteURL, ZONA_POLL_MS);
    } catch (e) {
        logERR("LAN", "setInterval failed: " + e);
    }
}

function refreshRemoteURL() {
    if (typeof XMLHttpRequest == "undefined") {
        logERR("LAN", "XMLHttpRequest not available");
        return;
    }
    var xhr;
    try {
        xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function() {
            if (xhr.readyState != 4) return;
            if (xhr.status == 200) {
                var u = String(xhr.responseText || "").replace(/^\s+|\s+$/g, "");
                if (u && u != lastRemoteURL) {
                    lastRemoteURL = u;
                    var input = document.getElementById("urlInput");
                    if (input) input.value = u;
                    logOK("LAN", "new URL received");
                    updateState("URL RECEIVED", "phone/PC/Telegram sent a new URL");
                    updateResult(u);
                    startTest();
                } else if (!u && lastRemoteURL) {
                    lastRemoteURL = "";
                    var emptyInput = document.getElementById("urlInput");
                    if (emptyInput) emptyInput.value = "";
                    logOK("LAN", "STOP command received");
                    updateState("STOP COMMAND", "Telegram/LAN requested stop");
                    stopPlayer();
                }
            } else if (xhr.status != 0) {
                logERR("LAN", "HTTP " + xhr.status);
            }
        };
        xhr.open("GET", ZONA_SERVER_URL + "/api/url?t=" + new Date().getTime(), true);
        xhr.send(null);
    } catch (e) {
        logERR("LAN", "request failed: " + e);
    }
}

function getURL() {
    var el = document.getElementById("urlInput");
    return el ? String(el.value) : "";
}

function editURL() {
    var input = document.getElementById("urlInput");
    if (!input) return;
    editingURL = true;
    updateState("EDIT URL", "Samsung IME active");
    try {
        input.focus();
        logOK("IME", "focus URL input");
    } catch (e) {
        logERR("IME", String(e));
    }
}

function finishEdit() {
    var input = document.getElementById("urlInput");
    if (input) {
        try { input.blur(); } catch (e) {}
    }
    editingURL = false;
    logOK("URL", "updated");
    updateState("READY", "URL edited");
}

function updateState(a, b) {
    document.getElementById("state").innerHTML =
        "<div>" + escapeHTML(a) + "</div><div>" + escapeHTML(b) + "</div>";
}

function updateEvent(text) {
    document.getElementById("lastEvent").innerHTML = escapeHTML(text);
}

function updateResult(text) {
    document.getElementById("lastResult").innerHTML = escapeHTML(text);
}

function updateStreamInfo(text) {
    document.getElementById("streamInfo").innerHTML = escapeHTML(text).replace(/\n/g, "<br>");
}

function logOK(tag, text) { pushLog("[OK]  " + tag + ": " + text); }
function logERR(tag, text) { pushLog("[ERR] " + tag + ": " + text); }

function pushLog(text) {
    logLines.push(text);
    if (logLines.length > 20) logLines.shift();
    renderLog();
}

function renderLog() {
    var i, html = "";
    for (i = 0; i < logLines.length; i++) {
        html += '<div class="logLine">' + escapeHTML(logLines[i]) + '</div>';
    }
    document.getElementById("log").innerHTML = html;
}

function escapeHTML(s) {
    s = String(s);
    return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function renderActions() {
    var i;
    for (i = 0; i < 4; i++) {
        document.getElementById("action" + i).className =
            "action" + (i == actionIndex ? " selected" : "");
    }
}

function keyHandler(e) {
    var key = e.keyCode;

    /* Samsung IME Done/Cancel. */
    if (editingURL && (key == 65376 || key == 65385)) {
        finishEdit();
        return;
    }

    if (editingURL) return;

    if (key == tvKey.KEY_UP || key == tvKey.KEY_LEFT) {
        actionIndex--;
        if (actionIndex < 0) actionIndex = 3;
        renderActions();
        return;
    }

    if (key == tvKey.KEY_DOWN || key == tvKey.KEY_RIGHT) {
        actionIndex++;
        if (actionIndex > 3) actionIndex = 0;
        renderActions();
        return;
    }

    if (key == tvKey.KEY_ENTER) {
        if (actionIndex == 0) startTest();
        else if (actionIndex == 1) editURL();
        else if (actionIndex == 2) refreshRemoteURL();
        else resetLog();
        return;
    }

    if (key == tvKey.KEY_RETURN || key == tvKey.KEY_STOP) {
        stopPlayer();
    }
}

document.onkeydown = keyHandler;

function startTest() {
    var ret;
    var url = getURL();

    if (!player) {
        logERR("Start", "Player object is NULL");
        return;
    }
    if (!url || url.indexOf("http") !== 0) {
        logERR("Start", "URL must start with http:// or https://");
        updateState("NOT STARTED", "invalid URL");
        return;
    }

    try { if (typeof player.Stop == "function") player.Stop(); } catch (ignore) {}

    updateState("STARTING", "InitPlayer -> StartPlayback");
    updateEvent("-");
    updateResult("-");
    updateStreamInfo("waiting for OnStreamInfoReady");
    logOK("URL", url);

    try {
        if (typeof player.InitPlayer != "function") {
            logERR("InitPlayer", "NOT FOUND");
            return;
        }

        ret = player.InitPlayer(url);
        logOK("InitPlayer", "return=" + String(ret));
        updateResult("InitPlayer=" + String(ret));

        if (typeof player.SetDisplayArea == "function") {
            ret = player.SetDisplayArea(0, 0, 1280, 720);
            logOK("SetDisplayArea", "return=" + String(ret));
        }

        if (typeof player.SetInitialBufferSize == "function") {
            ret = player.SetInitialBufferSize(400 * 1024);
            logOK("SetInitialBufferSize", "return=" + String(ret));
        } else if (typeof player.SetInitialBuffer == "function") {
            ret = player.SetInitialBuffer(400 * 1024);
            logOK("SetInitialBuffer", "return=" + String(ret));
        }

        if (typeof player.SetInitialTimeOut == "function") {
            ret = player.SetInitialTimeOut(30);
            logOK("SetInitialTimeOut", "return=" + String(ret));
        }

        if (typeof player.StartPlayback == "function") {
            ret = player.StartPlayback();
            logOK("StartPlayback", "return=" + String(ret));
            updateResult("StartPlayback=" + String(ret));
        } else if (typeof player.Play == "function") {
            ret = player.Play(url);
            logOK("Play", "return=" + String(ret));
            updateResult("Play=" + String(ret));
        } else {
            logERR("Playback", "StartPlayback/Play not available");
        }
    } catch (e) {
        logERR("EXCEPTION", String(e));
        updateResult("EXCEPTION: " + String(e));
    }
}

function stopPlayer() {
    try {
        if (player && typeof player.Stop == "function") {
            var ret = player.Stop();
            logOK("Stop", "return=" + String(ret));
            updateState("STOPPED", "player stopped");
        }
    } catch (e) {
        logERR("Stop", String(e));
    }
}

function resetLog() {
    logLines = [];
    renderLog();
    updateEvent("-");
    updateResult("-");
    updateStreamInfo("not available");
    logOK("Log", "reset");
}

/* Player callbacks */
function onBufferingStart() { updateEvent("OnBufferingStart"); updateState("BUFFERING", "buffering started"); logOK("EVENT", "OnBufferingStart"); }
function onBufferingProgress(p) { updateEvent("OnBufferingProgress(" + p + ")"); logOK("EVENT", "OnBufferingProgress=" + p); }
function onBufferingComplete() { updateEvent("OnBufferingComplete"); updateState("PLAYING", "buffering complete"); logOK("EVENT", "OnBufferingComplete"); }
function onConnectionFailed() { updateEvent("OnConnectionFailed"); updateState("ERROR", "connection failed"); logERR("EVENT", "OnConnectionFailed"); }
function onCurrentPlayTime(ms) { updateEvent("OnCurrentPlayTime(" + ms + ")"); }
function onNetworkDisconnected() { updateEvent("OnNetworkDisconnected"); updateState("ERROR", "network disconnected"); logERR("EVENT", "OnNetworkDisconnected"); }
function onRenderError() { updateEvent("OnRenderError"); updateState("ERROR", "render error"); logERR("EVENT", "OnRenderError"); }
function onRenderingComplete() { updateEvent("OnRenderingComplete"); updateState("ENDED", "rendering complete"); logOK("EVENT", "OnRenderingComplete"); }
function onResolutionChanged(w, h) { updateEvent("OnResolutionChanged"); logOK("EVENT", "OnResolutionChanged " + w + "x" + h); }

function onStreamInfoReady() {
    var width = "?", height = "?", bitrate = "?", available = "?", duration = "?";
    updateEvent("OnStreamInfoReady");
    updateState("STREAM INFO READY", "querying player information");

    try { if (typeof player.GetVideoWidth == "function") width = player.GetVideoWidth(); } catch (e1) { width = "ERR"; }
    try { if (typeof player.GetVideoHeight == "function") height = player.GetVideoHeight(); } catch (e2) { height = "ERR"; }
    try { if (typeof player.GetCurrentBitrates == "function") bitrate = player.GetCurrentBitrates(); } catch (e3) { bitrate = "ERR"; }
    try { if (typeof player.GetAvailableBitrates == "function") available = player.GetAvailableBitrates(); } catch (e4) { available = "ERR"; }
    try { if (typeof player.GetDuration == "function") duration = player.GetDuration(); } catch (e5) { duration = "ERR"; }

    updateStreamInfo("video: " + width + " x " + height + "\nbitrate: " + bitrate + "\navailable: " + available + "\nduration: " + duration);
    logOK("EVENT", "OnStreamInfoReady");
    logOK("INFO", width + "x" + height + ", bitrate=" + bitrate + ", duration=" + duration);
}

function onStreamNotFound() { updateEvent("OnStreamNotFound"); updateState("ERROR", "stream not found"); logERR("EVENT", "OnStreamNotFound"); }
function onAuthenticationFailed() { updateEvent("OnAuthenticationFailed"); updateState("ERROR", "authentication failed"); logERR("EVENT", "OnAuthenticationFailed"); }
