Zona Orsay v0.5.1 — Telegram + automatic LAN IP selection

WHAT CHANGED
------------
The PC server now automatically finds local IPv4 addresses and gives priority to
192.168.88.x (the current home LAN). VPN/private addresses such as 10.x.x.x are
kept as lower-priority candidates and are not advertised as the TV address when
192.168.88.x is present.

At startup server.py prints:
  LAN IP     : 192.168.88.228
  TV API     : http://192.168.88.228:8765/api/url
  LAN WEB    : http://192.168.88.228:8765/

The HTTP server still listens on 0.0.0.0 so Windows interface changes do not
break the service. The printed LAN IP is the address the TV should use.

WIDGET CONFIG
-------------
The Orsay TV cannot automatically read the PC's network interfaces. Therefore
js/config.js contains the current LAN address used by the widget:
  http://192.168.88.228:8765

If the home PC's LAN address changes, copy the newly printed LAN IP into
js/config.js and reinstall/repack the widget. The server itself does NOT need
editing.

If your home LAN changes from 192.168.88.x, set ZONA_LAN_PREFIX to the new
prefix before starting the server.

TELEGRAM
--------
Commands:
  /play https://example.com/video.mp4
  /stop
  /status
  /help

No third-party Python packages are required.

FIREWALL
--------
Allow Python/server.py on the Windows Private/Home network. TCP port 8765 is used.

The server transfers only the URL. The Samsung TV downloads the video directly
from the supplied media URL.
